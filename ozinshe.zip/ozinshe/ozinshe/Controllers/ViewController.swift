//
//  ViewController.swift
//  ozinshe
//
//  Created by Lazzat Anafiya on 24.05.2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

