//
//  ProfileViewController.swift
//  ozinshe
//
//  Created by Lazzat Anafiya on 01.06.2024.
//

import UIKit
import Localize_Swift

class ProfileViewController: UIViewController, LanguageProtocol {
    
    @IBOutlet weak var editLabel: UILabel!
    @IBOutlet weak var switchModeLabel: UILabel!
    @IBOutlet weak var passwordButton: UIButton!
    @IBOutlet weak var infosButton: UIButton!
    @IBOutlet weak var addView: UIView!
    @IBOutlet weak var myProfileLabel: UILabel!
    @IBOutlet weak var darkModeSwitch: UISwitch!
    @IBOutlet weak var languageLabel: UILabel!
    @IBOutlet weak var languageButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
    }
    override func viewWillAppear(_ animated: Bool) {
        configureView()
    }
    
    func configureView(){
        myProfileLabel.text = "MY_PROFILE".localized()
        infosButton.setTitle("INFO".localized(), for: .normal)
        editLabel.text = "EDIT".localized()
        passwordButton.setTitle("PASSWORD".localized(), for: .normal)
        switchModeLabel.text = "SWITCH".localized()
        
        
        languageButton.setTitle("LANGUAGE".localized(), for: .normal)
        
        if Localize.currentLanguage() == "en"{
            languageLabel.text = "English"
        }
        if Localize.currentLanguage() == "kk"{
            languageLabel.text = "Қазақша"
        }
        if Localize.currentLanguage() == "ru"{
            languageLabel.text = "Русский"
        }
    }
    
    @IBAction func languageShow(_ sender: Any) {
        let languageVC = storyboard?.instantiateViewController(withIdentifier: "LanguageViewController") as! LanguageViewController
        
        languageVC.modalPresentationStyle = .overCurrentContext
        
        languageVC.delegate = self
        
        present(languageVC, animated: true, completion: nil)
    }
    
    func languageDidChange() {
        configureView()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
